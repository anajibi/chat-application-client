#include <stdio.h>
#include <winsock2.h>
#include <windows.h>
#include "cJSON.c"
#include <string.h>

#define BLUE 1
#define RED 4
#define DEFAULTCOLOR 9
#define LOGIN 3
#define REGISTRATION 11
#define  OUTPUTFONT 40
#define PORT 12345
#define SA struct sockaddr

typedef struct {
    char username[50];
    char password[20];
} person;

void SetColor(int ForgC);
int Registration();
int Login();
void MainMenu();
int socketMaker();
int LoginMenu();
int chatting();
void ErrorPrinter(cJSON *serverRespond);
char serverToken[32] = {0};
person newPerson;

int main(void)
{

    while (1) {
        int option;
        MainMenu();
        InvalidUsername:
        scanf("%d", &option);
        switch (option) {
            case 1:
                while(Registration());
                break;
            case 2:
                while(Login());
                break;
            case 3:
                return 0;
            default:
                SetColor(RED);
                printf("Please enter a valid option.\n");
                SetColor(DEFAULTCOLOR);
                goto InvalidUsername;
        }
    }
}

void MainMenu(){
    SetColor(DEFAULTCOLOR);
    printf("Account menu:\n"
           "1: Register\n"
           "2: Login\n"
           "3: Exit\n");
}

int Login(){
    int socket;
    char message[120];
    char *respond;
    SetColor(LOGIN);
    printf("Enter your username\n");
    scanf("%s", newPerson.username);
    printf("Enter your password\n");
    scanf("%s", newPerson.password);
    //---------Contacting server----------//
    socket = socketMaker();
    snprintf(message, sizeof(message),"login %s, %s\n",newPerson.username,newPerson.password);
    send(socket, message, sizeof(message), 0);
    memset(message, 0, sizeof(message));
    recv(socket, message, sizeof(message), 0);
    cJSON *serverRespond = cJSON_Parse(message);
    respond = cJSON_GetObjectItem(serverRespond, "type") -> valuestring;
    //show the respond from server
    if(strcmp(respond, "Error") == 0){
        ErrorPrinter(serverRespond);
        return 0;
    } else{
        strcpy(serverToken, cJSON_GetObjectItem(serverRespond, "content") -> valuestring);
        //going to login Menu
        while(LoginMenu());
        return 0;
    }
}

int Registration(){
    int socket;
    char message[120];
    char *respond;

    SetColor(REGISTRATION);
    printf("Enter Your Username\n");
    scanf("%s", newPerson.username);
    printf("Enter Your Password\n");
    scanf("%s", newPerson.password);
    //---------Contacting server----------//
    socket = socketMaker();
    snprintf(message, sizeof(message),"register %s, %s\n",newPerson.username,newPerson.password);
    send(socket, message, sizeof(message), 0);
    memset(message, 0, sizeof(message));
    recv(socket, message, sizeof(message), 0);
    cJSON *serverRespond = cJSON_Parse(message);
    respond = cJSON_GetObjectItem(serverRespond, "type") -> valuestring;
    if(strcmp(respond, "Error") == 0){
        printf("This username has been taken, please retry\n");
        return 0;
    } else{
        printf("Username successfully created\n");
        return 0;
    }
}

int LoginMenu(){
    int socket;
    int option;
    char requestAndRespond[120];
    char channelName[30];
    char *respond;
    int c;
    SetColor(LOGIN);
    printf("1: Create Channel\n"
           "2: Join Channel\n"
           "3: Logout\n");
    while (1) {
        invalidOption:
        scanf("%d", &option);
        switch (option) {
            case 1:
                printf("Please enter channel name.(Your channel name should be 30 character at most.)\n");
                while ((c = getchar()) != '\n' && c != EOF) { }
                //-----------------------------------//
                scanf ("%30[^\n]%*c", channelName);
                snprintf(requestAndRespond, sizeof(requestAndRespond), "create channel %s, %s\n", channelName,
                         serverToken);
                socket = socketMaker();
                send(socket, requestAndRespond, sizeof(requestAndRespond), 0);
                memset(requestAndRespond, 0, sizeof(requestAndRespond));
                recv(socket, requestAndRespond, sizeof(requestAndRespond), 0);
                cJSON *serverRespond = cJSON_Parse(requestAndRespond);
                respond = cJSON_GetObjectItem(serverRespond, "type")->valuestring;
                //show the respond from server
                if (strcmp(respond, "Error") == 0) {
                    char *outputMessage = cJSON_GetObjectItem(serverRespond, "content")->valuestring;
                    printf("%s\n", outputMessage);
                    return 1;
                } else {
                    printf("Channel successfully created.\n");
                    while (chatting());
                    return 1;
                }
                break;
            case 2:
                socket = socketMaker();
                memset(requestAndRespond, 0, sizeof(requestAndRespond));
                memset(channelName, 0, sizeof(channelName));
                printf("Please enter channel name.(Your channel name should be 30 character at most.)\n");
                while ((c = getchar()) != '\n' && c != EOF) { }
                //-----------------------------------//
                scanf ("%30[^\n]%*c", channelName);
                snprintf(requestAndRespond, sizeof(requestAndRespond), "join channel %s, %s\n", channelName,
                         serverToken);
                send(socket, requestAndRespond, sizeof(requestAndRespond), 0);
                recv(socket, requestAndRespond, sizeof(requestAndRespond), 0);
               serverRespond = cJSON_Parse(requestAndRespond);
                respond = cJSON_GetObjectItem(serverRespond, "type")->valuestring;
                //show the respond from server
                if (strcmp(respond, "Error") == 0) {
                    char *outputMessage = cJSON_GetObjectItem(serverRespond, "content")->valuestring;
                    printf("%s\n", outputMessage);
                    return 1;
                } else {
                    printf("Successfully joined the channel.\n");
                    while (chatting());
                    return 1;
                }
                break;
            case 3:
                socket = socketMaker();
                memset(requestAndRespond, 0, sizeof(requestAndRespond));
                memset(channelName, 0, sizeof(channelName));
                snprintf(requestAndRespond, sizeof(requestAndRespond), "logout %s\n",
                         serverToken);
                send(socket, requestAndRespond, sizeof(requestAndRespond), 0);
                recv(socket, requestAndRespond, sizeof(requestAndRespond), 0);
                serverRespond = cJSON_Parse(requestAndRespond);
                respond = cJSON_GetObjectItem(serverRespond, "type")->valuestring;
                //show the respond from server
                if (strcmp(respond, "Error") == 0) {
                    char *outputMessage = cJSON_GetObjectItem(serverRespond, "content")->valuestring;
                    printf("%s\n", outputMessage);
                    return 1;
                } else {
                    printf("Logout successful.\n");
                    return 0;
                }
            default:
                SetColor(RED);
                printf("Please enter a valid option.\n");
                SetColor(LOGIN);
                goto invalidOption;
        }
    }
}

int chatting (){
    int option;
    int socket;
    char message[400];
    char requestAndRespond[100000];
    char *test;
    cJSON *serverRespond;
    printf("1: Send Message\n"
           "2: Refresh\n"
           "3: Channel Members\n"
           "4: Leave Channel\n");
    while (1) {
        invalidOption:
        scanf("%d",&option);
        switch (option) {
            case 1:
                printf("Please enter your message\n");
                //---------- Clearing Buffer----------//
                int c;
                while ((c = getchar()) != '\n' && c != EOF) { }
                //-----------------------------------//
                scanf ("%400[^\n]%*c", message);
                socket = socketMaker();
                snprintf(requestAndRespond, sizeof(requestAndRespond), "send %s, %s\n", message,
                         serverToken);
                send(socket, requestAndRespond, sizeof(requestAndRespond), 0);
                memset(requestAndRespond, 0, sizeof(requestAndRespond));
                recv(socket, requestAndRespond, sizeof(requestAndRespond), 0);
                serverRespond = cJSON_Parse(requestAndRespond);
                test = cJSON_GetObjectItem(serverRespond, "type")->valuestring;
                //show the respond from server
                if (strcmp(test, "Error") == 0) {
                    ErrorPrinter(serverRespond);
                    return 1;
                } else {
                    SetColor(BLUE);
                    printf("Message sent.\n");
                    SetColor(LOGIN);
                    return 1;
               }
            case 2:
                socket = socketMaker();
                memset(requestAndRespond, 0, sizeof(requestAndRespond));
                snprintf(requestAndRespond, sizeof(requestAndRespond), "refresh %s\n", serverToken);
                send(socket, requestAndRespond, sizeof(requestAndRespond), 0);
                memset(requestAndRespond, 0, sizeof(requestAndRespond));
                recv(socket, requestAndRespond, sizeof(requestAndRespond), 0);
                serverRespond = cJSON_Parse(requestAndRespond);
                test = cJSON_GetObjectItem(serverRespond, "type")->valuestring;
                //show the respond from server
                if (strcmp(test, "Error") == 0) {
                    ErrorPrinter(serverRespond);
                    return 1;
                } else {
                    cJSON* name = NULL;
                    cJSON *item = cJSON_GetObjectItem(serverRespond,"content");
                    for (int i = 0 ; i < cJSON_GetArraySize(item) ; i++)
                    {
                        cJSON * subitem = cJSON_GetArrayItem(item, i);
                        SetColor(OUTPUTFONT);
                        printf("%s: %s\n", cJSON_GetObjectItem(subitem, "sender")-> valuestring,
                                cJSON_GetObjectItem(subitem, "content")-> valuestring);
                    }
                    printf("\n");
                    SetColor(LOGIN);
                    return 1;
                }
            case 3:
                socket = socketMaker();
                snprintf(requestAndRespond, sizeof(requestAndRespond), "channel members %s\n", serverToken);
                send(socket, requestAndRespond, sizeof(requestAndRespond), 0);
                memset(requestAndRespond, 0, sizeof(requestAndRespond));
                recv(socket, requestAndRespond, sizeof(requestAndRespond), 0);
                serverRespond = cJSON_Parse(requestAndRespond);
                test = cJSON_GetObjectItem(serverRespond, "type")->valuestring;
                //show the respond from server
                if (strcmp(test, "Error") == 0) {
                    ErrorPrinter(serverRespond);
                    return 1;
                } else {
                    printf("Channel members are:\n");
                    SetColor(OUTPUTFONT);
                    cJSON *items = cJSON_GetObjectItem(serverRespond, "content");
                    for (int i = 0; i < cJSON_GetArraySize(items); ++i) {
                        printf("%s\n", cJSON_GetArrayItem(items, i)->valuestring);
                    }
                    printf("\n");
                    SetColor(LOGIN);
                    return 1;
                }
            case 4:
                socket = socketMaker();
                snprintf(requestAndRespond, sizeof(requestAndRespond), "leave %s\n", serverToken);
                send(socket, requestAndRespond, sizeof(requestAndRespond), 0);
                memset(requestAndRespond, 0, sizeof(requestAndRespond));
                recv(socket, requestAndRespond, sizeof(requestAndRespond), 0);
                serverRespond = cJSON_Parse(requestAndRespond);
                test = cJSON_GetObjectItem(serverRespond, "type")->valuestring;
                //show the respond from server
                if (strcmp(test, "Error") == 0) {
                    ErrorPrinter(serverRespond);
                    return 1;
                } else {
                    printf("You left the channel successfully.\n");
                    return 0;
                }
            default:
                SetColor(RED);
                printf("Please enter a valid option.\n");
                SetColor(LOGIN);
                goto invalidOption;
        }
    }
}

int socketMaker(){
        int client_socket, server_socket;
        struct sockaddr_in servaddr, cli;
        WORD wVersionRequested;
        WSADATA wsaData;
        int err;
        // Use the MAKEWORD(lowbyte, highbyte) macro declared in Windef.h
        wVersionRequested = MAKEWORD(2, 2);

        err = WSAStartup(wVersionRequested, &wsaData);
        if (err != 0) {
            // Tell the user that we could not find a usable Winsock DLL.
            printf("WSAStartup failed with error: %d\n", err);
            return NULL ;
        }

        // Create and verify socket
        client_socket = socket(AF_INET, SOCK_STREAM, 0);
        if (client_socket == -1) {
            printf("Socket creation failed...\n");
            exit(0);
        }
        else
           // printf("Socket successfully created..\n");
        // Assign IP and port
        memset(&servaddr, 0, sizeof(servaddr));
        servaddr.sin_family = AF_INET;
        servaddr.sin_addr.s_addr = inet_addr("127.0.0.1");
        servaddr.sin_port = htons(PORT);

        // Connect the client socket to server socket
        if (connect(client_socket, (SA*)&servaddr, sizeof(servaddr)) != 0) {
            printf("Connection to the server failed...\n");
            exit(0);
        }
        else
            //printf("Successfully connected to the server..\n");
        // Function for chat
    return client_socket;
        // Close the socket
    }

void SetColor(int ForgC)
{
    WORD wColor;

    HANDLE hStdOut = GetStdHandle(STD_OUTPUT_HANDLE);
    CONSOLE_SCREEN_BUFFER_INFO csbi;

    //We use csbi for the wAttributes word.
    if(GetConsoleScreenBufferInfo(hStdOut, &csbi))
    {
        //Mask out all but the background attribute, and add in the forgournd color
        wColor = (csbi.wAttributes & 0xF0) + (ForgC & 0x0F);
        SetConsoleTextAttribute(hStdOut, wColor);
    }
    return;
}

void ErrorPrinter(cJSON *serverRespond){
    SetColor(RED);
    char *outputMessage = cJSON_GetObjectItem(serverRespond, "content")->valuestring;
    printf("%s\n", outputMessage);
    SetColor(LOGIN);
}